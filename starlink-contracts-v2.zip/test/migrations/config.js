const addrs = {
    migrator: "0x495a579E587073534e2ee12563Eb505edC3eEbd8",
    token: "0x66D7F3Eb9Ee5725A233813B51Ee0D2E47e7c19AB",
    oldToken: "0x3E1AC2e38d877BB1C42871FBFd67d1B330F8eb7B",
    taxFeeCalc: "0xCD47303268d1e76AB7d4c98baa48Ddb23467b377",
    gameVault: "0xCca39038e2514Cbd2141374B3576A8Ec968B65cb",
    owner: "0x0E5AcB60073C7da8582942E43Df06b83F1a2d30c",
    tester: "0x42eD619fdb869d411f9e10BEFD2df4e3460c280F",
    tester2: "0xb7ca5d81e59e43594b88d822daa82fae80db6a9f",
    taxWallet: "0x398cA16bccD209Edbb25C0a5A57d759f98FDb921",
    deadAddr: "0x000000000000000000000000000000000000dEaD"
}

const proofs = {
    [addrs.owner]: ["0x39c0518493b55dd8ddee18fd598e0a9c4fe1028d6c104b3acca7ad7990d1d76c","0x786700f3ec2d58b8b74e225fc47ff8ac3895bcfd37920535361129b582f796ef","0xd4281f1015038831386a3ded4734986ff512a36b884acca47a9307db850ce46f","0xae57faa36db493d154b0f1bcdf3958edd6da191f9ae280e5b8f345a65e172470","0x9721ac94dc3e0f0695d5b38c5d7c1e96a80c0fd307620bfc3d68f35af9653aa4"],
    [addrs.tester]: ["0x1384c4c42f51f23246767f49ee20fdc8a5ac1da2d7a1932306dcc2a5ed7692ab","0xf63452c73102f2aacbbb9688b5d53f76c0898a59fd3bf678884deb1e62bfc07d","0x7d1e7ec6188e0027d943d067bfb0469e36d82a38eaee30823c29e2206174d3fa","0x720384901575137b1869d2935d429ca9506bd51228259d0aa9adbe0415558e24","0x9721ac94dc3e0f0695d5b38c5d7c1e96a80c0fd307620bfc3d68f35af9653aa4"]
}

const snapshots = {
    maxAmounts: {
        [addrs.owner]: "5590080757109",
        [addrs.tester]: "18399242891"
    }
}

module.exports = {
    addrs,
    proofs,
    snapshots
}