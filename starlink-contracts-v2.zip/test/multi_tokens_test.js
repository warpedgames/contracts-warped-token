const { loadFixture } = require("@nomicfoundation/hardhat-network-helpers");
const { time } = require("@openzeppelin/test-helpers");
const { expect } = require("chai");
const { BigNumber, Signer } = require("ethers");
const { ethers } = require("hardhat");
const dotenv = require("dotenv");
dotenv.config();

const getCurrentTime = async () => {
  const blockNumBefore = await ethers.provider.getBlockNumber();
  const blockBefore = await ethers.provider.getBlock(blockNumBefore);
  const timestampBefore = blockBefore.timestamp;
  // console.log("block: " + blockNumBefore + " : " + timestampBefore);
  return timestampBefore;
};

const increaseTime = async (dur) => {
  await ethers.provider.send("evm_increaseTime", [dur]);
};

const uri1 =
  "https://starlink.mypinata.cloud/ipfs/QmNzvtn5ujZeBAsepLnWNrFVHCdrnz1aApQrK7uNSuGoSS";
const uri2 =
  "https://starlink.mypinata.cloud/ipfs/QmPnSNmLjtXmXspzYebxpH5A1CoGeQx78Vs1EsNSHcxxBB";

describe("MultiTokens contract", function () {
  async function deployMTContractFixture() {
    const [owner, verifier, addr1, addr2] = await ethers.getSigners();

    const StarlMultiTokens = await ethers.getContractFactory(
      "StarlMultiTokens"
    );

    const currentTime = await getCurrentTime();
    const mintStartTime = currentTime + 10;

    const multiTokens = await StarlMultiTokens.deploy(verifier.address, process.env.STARL_ADDRESS);
    await multiTokens.deployed();
    console.log("STARL MultiTokens Contract: " + multiTokens.address);
    console.log("Owner: " + JSON.stringify(owner));
    console.log("Verifier1: " + JSON.stringify(verifier));
    console.log("Addr1: " + JSON.stringify(addr1));
    console.log("Addr2: " + JSON.stringify(addr2));

    await multiTokens.addTokensByUris(
      [uri1, uri2],
      [100, 100],
      [ethers.utils.parseEther("0.3")],
      [10, 20],
      [0, 2]
    );
    await increaseTime(20);
    console.log("Added tokens by uris");

    return { multiTokens, owner, verifier, addr1, addr2, mintStartTime };
  }

  it("DirectBuy", async function () {
    const { multiTokens, verifier, owner, addr1 } = await loadFixture(
      deployMTContractFixture
    );

    const _multiTokens = multiTokens.connect(addr1);

    await _multiTokens.directBuy(1, 10, {
      value: ethers.utils.parseEther("3"),
    });

    expect(await _multiTokens.balanceOf(addr1.address, 1)).to.equal(
      10,
      "Balance of tokens mismatched"
    );

    expect(
      _multiTokens.directBuy(2, 10, {
        value: ethers.utils.parseEther("3"),
      })
    ).to.be.revertedWith("Price not allowed");
  });

  it("maxMintAmountPerUser", async function() {    
    const { multiTokens, verifier, owner, addr1 } = await loadFixture(
      deployMTContractFixture
    );

    const _multiTokens = multiTokens.connect(addr1);

    await expect(_multiTokens.directBuy(1, 11, {
      value: ethers.utils.parseEther("3.3"),
    })).revertedWith("Exceed the limit per token");

    await _multiTokens.directBuy(1, 4, {
      value: ethers.utils.parseEther("1.2"),
    });
    
    await expect(_multiTokens.directBuy(1, 7, {
      value: ethers.utils.parseEther("2.1"),
    })).revertedWith("Exceed the limit per token");

    await _multiTokens.directBuy(1, 6, {
      value: ethers.utils.parseEther("1.8"),
    });
  })

  function addressToBytes(addr) {
    return ethers.utils.arrayify(addr);
  }

  function uint256ToBytes(num) {
    const hexNum = BigNumber.from(num).toHexString();
    return ethers.utils.zeroPad(ethers.utils.arrayify(hexNum), 32);
  }

  function hashVoucher(voucher) {
    let data = [];
    data = ethers.utils.concat([data, uint256ToBytes(voucher.voucherId)]);
    data = ethers.utils.concat([data, addressToBytes(voucher.nftAddress)]);
    data = ethers.utils.concat([data, uint256ToBytes(voucher.typeId)]);
    data = ethers.utils.concat([data, uint256ToBytes(voucher.amount)]);
    data = ethers.utils.concat([data, addressToBytes(voucher.maker)]);
    data = ethers.utils.concat([data, uint256ToBytes(voucher.expireTime)]);
    data = ethers.utils.concat([data, uint256ToBytes(voucher.salt)]);
    return ethers.utils.keccak256(data);
  }

  function hashToSign(voucher) {
    return ethers.utils.hashMessage(
      ethers.utils.arrayify(hashVoucher(voucher))
    );
  }

  async function voucherToParams(voucher, verifier) {
    const hash = hashVoucher(voucher);
    const sig = await verifier.signMessage(ethers.utils.arrayify(hash));
    const sigData = ethers.utils.splitSignature(sig);
    const intParams = [
      voucher.voucherId,
      voucher.typeId,
      voucher.amount,
      voucher.expireTime,
      voucher.salt,
      sigData.r,
      sigData.s,
    ];
    const addrParams = [voucher.nftAddress, voucher.maker];
    return { intParams, addrParams, sigV: sigData.v };
  }

  it("SwapWithVoucher", async function () {
    const { multiTokens, verifier, owner, addr1, addr2 } = await loadFixture(
      deployMTContractFixture
    );

    let _multiTokens = multiTokens.connect(addr1);

    const voucher = {
      voucherId: 1,
      nftAddress: _multiTokens.address,
      typeId: 2,
      amount: 5,
      maker: addr1.address,
      expireTime: (await getCurrentTime()) + 24 * 3600,
      salt: 30393,
    };
    const { intParams, addrParams, sigV } = await voucherToParams(
      voucher,
      verifier
    );

    expect(await _multiTokens.balanceOf(owner.address, 2)).to.equal(
      100,
      "Balance of tokens mismatched"
    );
    await _multiTokens.swapWithVoucher(intParams, addrParams, sigV);

    expect(await _multiTokens.balanceOf(addr1.address, 2)).to.equal(
      5,
      "Balance of tokens mismatched"
    );

    const {
      intParams: intParams2,
      addrParams: addrParams2,
      sigV: sigV2,
    } = await voucherToParams({ ...voucher, typeId: 1 }, verifier);
    _multiTokens = multiTokens.connect(addr2);
    expect(
      _multiTokens.swapWithVoucher(intParams2, addrParams2, sigV2)
    ).to.be.revertedWith("Swap with voucher not allowed");
  });
});
