const { loadFixture } = require("@nomicfoundation/hardhat-network-helpers");
const { time } = require("@openzeppelin/test-helpers");
const { expect } = require("chai");
const { BigNumber } = require("ethers");
const { ethers } = require("hardhat");

const getCurrentTime = async () => {
  const blockNumBefore = await ethers.provider.getBlockNumber();
  const blockBefore = await ethers.provider.getBlock(blockNumBefore);
  const timestampBefore = blockBefore.timestamp;
  console.log("block: " + blockNumBefore + " : " + timestampBefore);
  return timestampBefore;
};

const increaseTime = async (dur) => {
  await ethers.provider.send("evm_increaseTime", [dur]);
};

const pendingURI =
  "https://starlink.mypinata.cloud/ipfs/QmVEJJyyQRTuiGeFFq1hmbjmuNK3EipdR5uk38eqcPDVZe";
describe("PAL contract", function () {
  async function deployPALContractFixture() {
    const [owner, addr1, addr2] = await ethers.getSigners();

    const StarlPal = await ethers.getContractFactory("StarlPAL");

    const currentTime = await getCurrentTime();
    const mintStartTime = currentTime + 10;

    const palContract = await StarlPal.deploy(pendingURI, mintStartTime, 10);
    await palContract.deployed();
    console.log("STARL PAL Contract: " + palContract.address);
    console.log("Owner: " + JSON.stringify(owner));
    console.log("Addr1: " + JSON.stringify(addr1));
    console.log("Addr2: " + JSON.stringify(addr2));

    return { palContract, owner, addr1, addr2, mintStartTime };
  }

  it("Should reserve 10 nfts", async function () {
    const { palContract, owner, mintStartTime, addr1 } = await loadFixture(
      deployPALContractFixture
    );
    expect(await palContract.totalSupply()).to.equal(10);
    expect(await palContract.balanceOf(owner.address)).to.equal(10);
  });

  it("Should assign the pending uri and mint start time", async function () {
    const {
      palContract: _palContract,
      owner,
      mintStartTime,
      addr1,
    } = await loadFixture(deployPALContractFixture);
    const palContract = _palContract.connect(addr1);
    expect(await palContract.owner()).to.equal(owner.address);
    expect(await palContract.pendingURI()).to.equal(pendingURI);

    await expect(
      palContract.mint(addr1.address, 1, {
        value: ethers.utils.parseEther("0.08"),
      })
    ).to.be.revertedWith("Mint Not started");

    const currentTime = await getCurrentTime();
    const diff = mintStartTime - currentTime;
    console.log("Time diff: " + diff);
    await increaseTime(diff + 3);

    await palContract.mint(addr1.address, 1, {
      value: ethers.utils.parseEther("0.08"),
    });
    expect(await palContract.balanceOf(addr1.address)).to.equal(
      1,
      "Mint failed"
    );
  });

  // it("Should mint less than 30 nfts per wallet and transaction", async function () {
  //   const {
  //     palContract: _palContract,
  //     owner,
  //     mintStartTime,
  //     addr2,
  //   } = await loadFixture(deployPALContractFixture);

  //   const currentTime = await getCurrentTime();
  //   const diff = mintStartTime - currentTime;
  //   await increaseTime(diff + 2);

  //   const palContract = _palContract.connect(addr2);

  //   await expect(
  //     palContract.mint(addr2.address, 0, {
  //       value: ethers.utils.parseEther("0"),
  //     }),
  //     "Failed checking zero mint amount"
  //   ).to.be.revertedWith("Invalid mintAmount");

  //   await expect(
  //     palContract.mint(addr2.address, 99, {
  //       value: ethers.utils.parseEther("2.48"),
  //     }),
  //     "Failed checking over mint amount"
  //   ).to.be.revertedWith("maxMintAmount exceed");

  //   await palContract.mint(addr2.address, 1, {
  //     value: ethers.utils.parseEther("0.08"),
  //   });
  //   expect(await palContract.balanceOf(addr2.address)).to.equal(
  //     1,
  //     "1 nft Mint filed"
  //   );

  //   await palContract.mint(addr2.address, 3, {
  //     value: ethers.utils.parseEther("0.24"),
  //   });
  //   expect(await palContract.balanceOf(addr2.address)).to.equal(
  //     4,
  //     "3 nfts mint failed"
  //   );

  //   await expect(
  //     palContract.mint(addr2.address, 29, {
  //       value: ethers.utils.parseEther("2.32"),
  //     }),
  //     "Failed checking over left mint amount"
  //   ).to.be.revertedWith("You cant mint more items than left mint amount");
  // });

  it("Should fail for invalid amount of ether", async function () {
    const {
      palContract: _palContract,
      owner,
      mintStartTime,
      addr2,
    } = await loadFixture(deployPALContractFixture);

    const currentTime = await getCurrentTime();
    const diff = mintStartTime - currentTime;
    await increaseTime(diff + 2);

    const palContract = _palContract.connect(addr2);

    await expect(
      palContract.mint(addr2.address, 1, {
        value: ethers.utils.parseEther("0"),
      }),
      "Failed checking zero price minting"
    ).to.be.revertedWith("Insufficient amount of ether");

    await expect(
      palContract.mint(addr2.address, 10, {
        value: ethers.utils.parseEther("0.08"),
      }),
      "Failed checking low price minting"
    ).to.be.revertedWith("Insufficient amount of ether");

    await expect(
      palContract.mint(addr2.address, 20, {
        value: ethers.utils.parseEther("1"),
      }),
      "Failed checking low price minting"
    ).to.be.revertedWith("Insufficient amount of ether");
  });

  // it("Should fail for over minting", async function () {
  //   const {
  //     palContract: _palContract,
  //     owner,
  //     mintStartTime,
  //     addr2,
  //   } = await loadFixture(deployPALContractFixture);

  //   const currentTime = await getCurrentTime();
  //   const diff = mintStartTime - currentTime;
  //   await increaseTime(diff + 2);

  //   const palContract = _palContract.connect(addr2);

  //   await palContract.mint(addr2.address, 30, {
  //     value: ethers.utils.parseEther("2.4"),
  //   });

  //   await expect(
  //     palContract.mint(addr2.address, 30, {
  //       value: ethers.utils.parseEther("2.4"),
  //     }),
  //     "Failed checking over minting"
  //   ).to.be.revertedWith("You cant mint more items than left mint amount");
  // });

  it("Should withdraw correct amount of ether", async function () {
    const {
      palContract: _palContract,
      owner,
      mintStartTime,
      addr1,
      addr2,
    } = await loadFixture(deployPALContractFixture);

    const currentTime = await getCurrentTime();
    const diff = mintStartTime - currentTime;
    await increaseTime(diff + 2);

    const palContract1 = _palContract.connect(addr1);

    await palContract1.mint(addr1.address, 30, {
      value: ethers.utils.parseEther("2.4"),
    });

    const palContract2 = _palContract.connect(addr2);

    await palContract2.mint(addr2.address, 30, {
      value: ethers.utils.parseEther("2.4"),
    });

    await expect(await _palContract.withdraw()).to.changeEtherBalance(
      owner,
      ethers.utils.parseEther("4.8")
    );
  });

  it("Should update mint start time", async function () {
    const { palContract, owner, mintStartTime, addr1, addr2 } =
      await loadFixture(deployPALContractFixture);

    const currentTime = await getCurrentTime();
    const diff = mintStartTime - currentTime;
    await increaseTime(diff + 2);

    const palContract1 = palContract.connect(addr1);
    await palContract1.mint(addr1.address, 10, {
      value: ethers.utils.parseEther("0.8"),
    });

    await palContract.setMintStartTime(mintStartTime + 10);

    expect(await palContract.mintStartTime()).to.equal(mintStartTime + 10);

    await expect(
      palContract1.mint(addr1.address, 20, {
        value: ethers.utils.parseEther("1.6"),
      })
    ).to.revertedWith("Mint Not started");
  });

  it("Should reveal correctly", async function () {
    const { palContract, owner, mintStartTime, addr1, addr2 } =
      await loadFixture(deployPALContractFixture);

    const currentTime = await getCurrentTime();
    const diff = mintStartTime - currentTime;
    await increaseTime(diff + 2);
    const palContract1 = palContract.connect(addr1);
    await palContract1.mint(addr1.address, 30, {
      value: ethers.utils.parseEther("2.4"),
    });
    const palContract2 = palContract.connect(addr2);
    await palContract2.mint(addr2.address, 60, {
      value: ethers.utils.parseEther("4.8"),
    });

    // for (let j = 0; j < 39; j++) {
    //   await palContract.mint(owner.address, 250, {
    //     value: ethers.utils.parseEther("0"),
    //   });
    // }
    // await palContract.mint(owner.address, 190, {
    //   value: ethers.utils.parseEther("0"),
    // });

    await expect(
      palContract2.mint(addr2.address, 10, {
        value: ethers.utils.parseEther("0.8"),
      })
    ).to.revertedWith("Total supply exceed");

    const revealUri =
      "https://starlink.mypinata.cloud/ipfs/QmcW5hnFTTnkG7AHNHYy1MvJT9dAYWCLp8G7oPi7oweVRT/PAL";
    await palContract.reveal(revealUri, ".json");

    const testIds = [1, 3, 5, 10, 25, 70];
    for (let i = 0; i < testIds.length; i++) {
      const tokenId = testIds[i];
      expect(await palContract.tokenURI(tokenId)).to.equal(
        revealUri + tokenId + ".json"
      );
    }
  });
});
