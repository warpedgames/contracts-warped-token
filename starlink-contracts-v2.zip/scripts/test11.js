const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

async function main() {
    const url = "https://starlink.mypinata.cloud/ipfs/QmZzZbtfqaqjkT53S2SLbSzD6zsvukXyDphrdsKRqcyYR9/PAL";
    const start = 1878;
    const end = 2000;
    for(let i=start+1; i<=end; i++) {
        const res = await fetch(url + i + ".json").then(r => r.json())
        const special = res.attributes.filter(a => a.trait_type == 'Special')[0].value
        if (special !== "None") {
            console.log("Found " + i + " : " + special)
        } else {
            console.log("Skipping " + i)
        }
    }
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
