// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");
const fs = require('fs')
const csv = require('csv-parser')
const dotenv = require("dotenv")

dotenv.config()

async function main() {
  // Hardhat always runs the compile task when running scripts with its command
  // line interface.
  //
  // If this script is run directly using `node` you may want to call compile
  // manually to make sure everything is compiled
  // await hre.run('compile');

  // We get the contract to deploy
  const STARLNftStaking = await hre.ethers.getContractFactory("STARLNftStaking");
  // Replace STARL address for mainnet
  const nftStaking = await STARLNftStaking.deploy("0x5a168798df2b9d84e28958702156b036927a9e29");

  await nftStaking.deployed();

  console.log("STARLNftStaking:", nftStaking.address);

  // Replace or update: PN address for mainnet, start time, end time, [rate_of_tier0, rate_of_tier1, rate_of_tier2]
  const pnAddress = "0x5c2225acc3518aA78Aa4e112E590A2f73946f971";

  // !!! MAKE SURE to update the start time: the second parameter, and update the third parameter: end time.
  await nftStaking.addNftStaking(pnAddress, "1642166400", "1643630400", [
    "10000000000000000", "100000000000000000", "500000000000000000","1000000000000000000", "5000000000000000000"
  ]);

}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main();

