const hre = require("hardhat");
const dotenv = require("dotenv");
dotenv.config();

async function main() {

  // We get the contract to deploy
  const AmoebaXStarl = await hre.ethers.getContractFactory("AmoebaXStarl");
  const amxst = await AmoebaXStarl.deploy(
      process.env.DEV_FEE_RECIPIENT,
      process.env.AMOEBA_RECIPIENT,
      [100, 100],
      1650624240,
      [process.env.FIRST_ARTIST_RECIPIENT, process.env.SECOND_ARTIST_RECIPIENT],
      ["https://starlink.mypinata.cloud/ipfs/QmaQ1wUqpBCLRspxgdQ2G32wVheQygLWYnNDJRbHPZeJGD/", "https://starlink.mypinata.cloud/ipfs/QmewmGmjT7YNDbpa7cAuobFSeWzoz5hWrS1RWF3utA9qWY/"],
      ".json"
  );

  await amxst.deployed();

  console.log("AmoebaXStarl:", amxst.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
