const csv = require('csv-parser')
const fs = require("fs")
const hre = require("hardhat");
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const loadHolders = async () => {
    const holders = []
    const promise = new Promise((resolve) => {
        fs.createReadStream("data/migrations/goerli_starlink_holders.csv")
          .pipe(csv())
          .on("data", (item) => {
            holders.push(item);
          })
          .on("end", async () => {
            resolve(holders)
          })
    })
    return promise
}

const constructMerkleTree = async () => {
    const holders = await loadHolders()
    const nonZeroHolders = holders.map(h => {
      let hstr = h['HolderAddress']
      const hb = h['Balance'].toLowerCase()
      let hbal = hb.includes("e+") ? parseFloat(hb.split("e+")[0] + 'e+' + (parseInt(hb.split("e+")[1])-18)).toFixed() : parseFloat(hb).toFixed()
      return {address: hstr.toLowerCase(), amount: parseInt(hbal)}
    }).filter(h => h.amount > 0)
    
    console.log("nonZeroHolders " + nonZeroHolders.length);
    const bodyData = JSON.stringify({holders: nonZeroHolders})
    return fetch("http://localhost:3001/migration/upload-snapshot", {
      method: "POST",
      headers: {
        "Authorization": "API_KEY bdhQexg73961NfudreNlp36Xhr8WqnM",
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(bodyData),
      },
      body: bodyData
    }, 100000).then((r) => r.json()).then(d => {
      console.log("Successfully uploaded: " + JSON.stringify(d));
      return d.root_hash;
    })
}

const mainnetAddresses = require('../../addresses/mainnet.json');
const goerliAddresses = require('../../addresses/goerli.json');
const addresses = process.env.NETWORK === 'mainnet' ? mainnetAddresses : goerliAddresses;
let merkleRoot = '';

async function main() {
  if (!merkleRoot) {
    merkleRoot = await constructMerkleTree();
    console.log("merkleRoot: " + merkleRoot);
  }

  const TaxFeeCalculator = await hre.ethers.getContractFactory("TaxFeeCalculator");
  const taxFeeCalculator = await TaxFeeCalculator.deploy([
    addresses.SATE_NFT_ADDRESS, addresses.LMVX_NFT_ADDRESS, addresses.STPAL_NFT_ADDRESS, addresses.STPN_NFT_ADDRESS
  ], [4, 2, 1, 1]);
  await taxFeeCalculator.deployed();
  console.log("TaxFeeCalculator:", taxFeeCalculator.address);
  
  const StarlMigrator = await hre.ethers.getContractFactory("StarlMigrator");
  const migrator = await StarlMigrator.deploy();
  await migrator.deployed();
  console.log("StarlMigrator:", migrator.address);

  const StarlV2Token = await hre.ethers.getContractFactory("StarlToken");
  const starlV2Token = await StarlV2Token.deploy(taxFeeCalculator.address, addresses.TAX_WALLET, migrator.address);
  await starlV2Token.deployed();
  console.log("StarlV2Token:", starlV2Token.address);

  
  const GameRewardVault = await hre.ethers.getContractFactory("GameRewardVault");
  const gameRewardVault = await GameRewardVault.deploy(starlV2Token.address);
  await gameRewardVault.deployed();
  console.log("Game reward vault contract: " + gameRewardVault.address);

  await starlV2Token.setRewardVault(gameRewardVault.address);
  await migrator.openMigration(merkleRoot, addresses.STARL_ADDRESS, starlV2Token.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });