const mainnetAddresses = require('../../addresses/mainnet.json');
const goerliAddresses = require('../../addresses/goerli.json');
const addresses = goerliAddresses;

const params = [
    [addresses.SATE_NFT_ADDRESS, addresses.LMVX_NFT_ADDRESS, addresses.STPAL_NFT_ADDRESS, addresses.STPN_NFT_ADDRESS],
    [4,2,1,1]
]

module.exports = params;