module.exports = [
  process.env.VOUCHER_VERIFIER_ADDRESS,
  process.env.STARL_ADDRESS,
  process.env.MT_DEFAULT_ROYALTY_ADDRESS,
  1000
];
