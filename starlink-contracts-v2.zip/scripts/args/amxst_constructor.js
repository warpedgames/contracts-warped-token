const dotenv = require("dotenv");
dotenv.config();

module.exports = [
    process.env.DEV_FEE_RECIPIENT,
    process.env.AMOEBA_RECIPIENT,
    [100, 100],
    1650624240,
    [process.env.FIRST_ARTIST_RECIPIENT, process.env.SECOND_ARTIST_RECIPIENT],
    ["https://starlink.mypinata.cloud/ipfs/QmaQ1wUqpBCLRspxgdQ2G32wVheQygLWYnNDJRbHPZeJGD/", "https://starlink.mypinata.cloud/ipfs/QmewmGmjT7YNDbpa7cAuobFSeWzoz5hWrS1RWF3utA9qWY/"],
    ".json"
];