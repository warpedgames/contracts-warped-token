module.exports = [process.env.STARL_ADDRESS, 3];
