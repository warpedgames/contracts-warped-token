// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");
const fs = require('fs');
const csv = require('csv-parser');
const dotenv = require("dotenv");

dotenv.config();


async function main() {
  // Hardhat always runs the compile task when running scripts with its command
  // line interface.
  //
  // If this script is run directly using `node` you may want to call compile
  // manually to make sure everything is compiled
  // await hre.run('compile');

  // We get the contract to deploy
  const STARLNftStaking = await hre.ethers.getContractFactory("STARLNftStaking");
  const nftStaking = await STARLNftStaking.attach("0x8F130c70484805576F9A43bb3a9BCC2F42469DE3");
  const pnAddress = "0x5c2225acc3518aA78Aa4e112E590A2f73946f971";

  let tokens_660 = []
  fs.createReadStream('data/pn_ranks_600_parsed.csv').pipe(csv()).on('data', (data) => {
    tokens_660.push(data)
  }).on('end', async () => {
    const tiers = [10, 50, 100, 500];
    let nTier = 0;
    let tokens = [];
    for (let i=0; i<tokens_660.length; i++) {
        if (tokens.length < tiers[nTier]) {
            tokens.push(tokens_660[i].pn_num);
        } else {
            nTier = nTier + 1;
            console.log(JSON.stringify(tokens));
            await nftStaking.setTiers(pnAddress, tokens, nTier);
            tokens = [tokens_660[i].pn_num];
        }
    }
    nTier = nTier + 1;
    console.log(JSON.stringify(tokens));
    await nftStaking.setTiers(pnAddress, tokens, nTier);
  });
}


main();