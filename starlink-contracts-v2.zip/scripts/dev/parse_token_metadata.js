const dotenv = require("dotenv");
const csv = require("csv-parser");
const fs = require("fs");
const axios = require("axios").default;
dotenv.config();

async function writeTokenMetadata() {
  const promise = new Promise(async (resolve) => {
    let baseURI =
      "https://starlink.mypinata.cloud/ipfs/QmXQm4BDGdhJjPRjiJmSScs7XuRWz6pTRKeuUE2xgBAhFS/";
    let texts = [
      "TokenID,Name,Background,Suit,Antenna,Helmet,Face,Alien,RarityScore\n",
    ];
    let freq = {};
    let traits = [];
    const keys = ["background", "suit", "antenna", "helmet", "face", "alien"];
    let lines = ["id,name," + keys.join(",")];
    let data = [];
    const count = 9998;
    for (let id = 1; id <= count; id++) {
      let r = null;
      while (!r) {
        try {
          r = await axios(`${baseURI}/${id}`, { timeout: 60000 });
        } catch (err) {
          console.log(err);
        }
      }
      const rd = r.data;
      const attrs = {};
      for (let j = 0; j < keys.length; j++) {
        attrs[keys[j]] = rd.attributes.filter(
          (a) => a.trait_type.toLowerCase() === keys[j]
        )[0].value;
      }
      console.log("Parsing: " + id);
      const line = `${id},${rd.name},${attrs["background"]},${attrs["suit"]},${attrs["antenna"]},${attrs["helmet"]},${attrs["face"]},${attrs["alien"]}`;
      texts.push(line);
      for (let j = 0; j < keys.length; j++) {
        const attr = attrs[keys[j]];
        if (!freq[attr]) {
          freq[attr] = 1;
        } else {
          freq[attr] += 1;
        }
      }
      traits.push(attrs);
      lines.push(line);
    }
    // for(id=1; id<=count; id++) {
    //     let rarityScore = 100000000
    //     console.log("attr " + JSON.stringify(freq[traits[id-1][keys[j]]]))
    //     for(let j=0; j<keys.length; j++) {
    //         rarityScore = rarityScore * (1/freq[traits[id-1][keys[j]]])
    //     }
    //     // rarityScore = Math.floor(rarityScore)
    //     console.log("rarity: " + rarityScore)
    //     lines[id-1] += `,${rarityScore}`
    // }
    fs.writeFile("data/pn_metadata.csv", lines.join("\n"), () => {
      resolve();
    });
  });
  return promise;
}

async function parseTokenMetadata() {
  const promise = new Promise(async (resolve) => {
    let baseURI =
      "https://starlink.mypinata.cloud/ipfs/QmXQm4BDGdhJjPRjiJmSScs7XuRWz6pTRKeuUE2xgBAhFS/";
    let texts = [
      "TokenID,Name,Background,Suit,Antenna,Helmet,Face,Alien,RarityScore\n",
    ];
    let freq = {};
    let traits = [];
    const keys = ["background", "suit", "antenna", "helmet", "face", "alien"];
    let lines = ["id,name," + keys.join(",") + ",rarity"];
    let data = [];
    let traitValues = {};
    const count = 9998;
    fs.createReadStream("data/pn_metadata.csv")
      .pipe(csv())
      .on("data", (item) => {
        data.push(item);
      })
      .on("end", async () => {
        for (let i = 0; i < keys.length; i++) {
          freq[keys[i]] = {};
        }
        for (let id = 1; id <= count; id++) {
          const attrs = {};
          for (let j = 0; j < keys.length; j++) {
            attrs[keys[j]] = data[id - 1][keys[j]];
          }
          // console.log("Parsing: "+ id)
          const line = `${id},${data[id - 1].name},${attrs["background"]},${
            attrs["suit"]
          },${attrs["antenna"]},${attrs["helmet"]},${attrs["face"]},${
            attrs["alien"]
          }`;
          texts.push(line);
          for (let j = 0; j < keys.length; j++) {
            const attr = attrs[keys[j]];
            if (!freq[keys[j]][attr]) {
              freq[keys[j]][attr] = 1;
            } else {
              freq[keys[j]][attr] += 1;
            }
            if (!traitValues[keys[j]]) {
              traitValues[keys[j]] = [attr];
            } else if (traitValues[keys[j]].indexOf(attr) < 0) {
              traitValues[keys[j]].push(attr);
            }
          }
          traits.push(attrs);
          lines.push(line);
        }
        let minFreq = {},
          maxFreq = {};
        for (id = 1; id <= count; id++) {
          for (let j = 0; j < keys.length; j++) {
            const key = keys[j];
            const f = 1 / freq[keys[j]][traits[id - 1][key]];
            if (!minFreq[key]) {
              minFreq[key] = 1;
            }
            if (minFreq[key] > f) {
              minFreq[key] = f;
            }
            if (!maxFreq[key]) {
              maxFreq[key] = 0;
            }
            if (maxFreq[key] < f) {
              maxFreq[key] = f;
            }
          }
        }
        console.log("max " + JSON.stringify(maxFreq));
        console.log("min " + JSON.stringify(minFreq));
        for (id = 1; id <= count; id++) {
          let rarityScore = 0;
          for (let j = 0; j < keys.length; j++) {
            const key = keys[j];
            const f =
              (1 /
                (freq[key][traits[id - 1][key]] / 10000) /
                traitValues[keys[j]].length) *
              10;
            const min = minFreq[keys[j]];
            const max = maxFreq[keys[j]];
            rarityScore = rarityScore + f;
            // console.log("keys[j] " + freq[key][traits[id-1][key]] + " : " + traits[id-1][key] + ", r " + f)
          }
          // rarityScore = Math.floor(rarityScore)
          console.log("rarity: " + rarityScore);
          lines[id] += `,${rarityScore}`;
        }
        fs.writeFile(
          "data/pn_metadata_with_rarity.csv",
          lines.join("\n"),
          () => {
            resolve();
          }
        );
      });
  });
  return promise;
}

parseTokenMetadata()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
